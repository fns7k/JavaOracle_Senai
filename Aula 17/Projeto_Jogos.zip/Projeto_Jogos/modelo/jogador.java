package modelo;

public class jogador {
	// Personagem do jogo
	String nickname;
	double altura;
	int idade;
	String roupagem;
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getRoupagem() {
		return roupagem;
	}
	public void setRoupagem(String roupagem) {
		this.roupagem = roupagem;
	}
	
}
